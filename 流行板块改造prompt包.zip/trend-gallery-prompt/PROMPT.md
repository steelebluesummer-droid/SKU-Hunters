# Claude Code 任务：改造「流行元素」板块页面（TrendGallery）

## 背景

项目里有一个流行元素板 / Trend Gallery 页面（设计师 Moodboard 性质的页面），源码在：

- 主文件：`frontend/src/features/dashboard/TrendGallery.jsx`
- 参考素材（仓库已有，可对照风格）：
  - `design/01_侧边栏_洞察数据/03_流行元素/`（WGSN 色彩趋势板、CMF 趋势报告等 8 张参考图）
  - `design/03_最终企划案/03_Moodboard/时尚系列概念情绪板2.webp`（最终验收对照物）
- 项目已有 CSS tokens：`--color-*` 变量
- 后端有即梦生图服务：`backend/app/services/jimeng.py`（后续可用它按品牌调性统一生成示意纹理图）

当前页面的问题：**它现在是一张数据报表，不是情绪板**。通篇 antd 默认 `Card` + 纯文字列表，唯一的视觉元素是 48px 高的小色条，完全没有时尚感。

具体症结：

1. **零图像**：花纹、形态、表情化三个区块全是纯文字卡片。「Y2K 辣妹贴钻」「库洛米 IP 印花」这种内容全靠读者脑补。
2. **色卡太小气**：配色是整个页面唯一「看得见」的趋势，色块只有 48px 高、带白边和边框，没有色彩冲击力。
3. **表情化区块视觉塌陷**：代码渲染 `e.emoji`，但接口没返回 emoji 字段，5 张卡全是白底文字。
4. **无视觉层级**：四个区块卡片等大、等距、同灰度，没有 hero、没有焦点。
5. **参考图早已调研好**（见上面 design 目录），只是没落到代码里。

## 任务目标

把「趋势」从文字变回图像：色卡放大、花纹 / 形态 / 表情全部配图、Bento 拼版制造焦点。改完后和 `design/03_最终企划案/03_Moodboard/时尚系列概念情绪板2.webp` 放一起看，「图多字少、色彩扑面」即达标。

## 随包素材

本 zip 内 `images/` 目录有 15 张已人工筛选确认贴题的配图，按卡片一一对应（见下方映射表）。请把它们放进前端静态资源目录（如 `frontend/src/assets/trend/` 或 `frontend/public/trend/`），并在数据中为对应条目补上 `image` 字段引用。

> 版权提醒：这些图来自公开网络搜索，做页面占位、内部 demo、moodboard 没问题；**商用上架前需换成自有版权图或采集样本图**（尤其三丽鸥 IP 和戴森产品图有版权），代码里建议把图片路径抽成数据字段，方便后续替换。

## 分区改造要求

### 1. 配色趋势 → 全出血色卡墙

- 色块从 48px 提到 120–160px 高，去掉白边圆角卡片壳，让颜色铺满整个卡片（Pantone 色卡版式：大色面 + 底部色名 / 编号 / hex 压暗条）。
- 点击色卡复制 hex 到剪贴板（`navigator.clipboard`）。
- 给「年度色」（Cloud Dancer、Transformative Teal）加 `2026 年度色` 角标或放大一号卡片，制造焦点。

### 2. 花纹图案 / 形态结构 → 图像缩略图卡

- 文字卡升级为「上图下文」：一张代表性图片 + 名称 + 一句话 note。
- `source`（Pantone 11-4201、WGSN 等）弱化成卡片底部小灰字，不要和标题抢视觉。

图片映射（花纹图案 5 张）：

| 卡片 | 图片文件 |
|---|---|
| 不规则圆点（治愈系印花趋势） | `images/pattern_01_不规则圆点.jpg` |
| 水彩晕染 / 云朵纹理（低饱和莫兰迪方向） | `images/pattern_02_水彩晕染云朵纹理.jpg` |
| 抽象有机形态（潘通 13-0000 Ivory 配色） | `images/pattern_03_抽象有机形态.jpg` |
| 千禧年 Y2K 辣妹贴钻（手持款配饰化） | `images/pattern_04_Y2K辣妹贴钻.jpg` |
| IP 卡通形象印花（凯蒂猫 / 库洛米 / Chiikawa） | `images/pattern_05_IP卡通印花.jpg` |

图片映射（形态结构 5 张）：

| 卡片 | 图片文件 |
|---|---|
| 立式挂脖（解放双手，挂脖款主流形态） | `images/shape_01_立式挂脖.jpg` |
| 折叠手持 / 桌面两用（倍思路线，2026 趋势） | `images/shape_02_折叠手持桌面两用.jpg` |
| 复古桌面摇头（情绪价值款） | `images/shape_03_复古桌面摇头.jpg` |
| 无叶涡轮（戴森 / 徕芬高端线） | `images/shape_04_无叶涡轮.jpg` |
| 挂件 mini（25-50 元 IP 联名挂件款） | `images/shape_05_挂件mini.jpg` |

### 3. 表情化趋势 → 修复 + 情绪化视觉

- 先修 bug：emoji 为空时卡片居中留白。要么后端补 emoji 字段，要么前端给占位处理。
- 这一区讲「IP 情绪语言」，用下面 5 张图做成 2–3 列的大图卡。

图片映射（表情化趋势 5 张）：

| 卡片 | 图片文件 |
|---|---|
| 打工人体面（白色桌面小风扇 + 精致工位场景） | `images/expr_01_打工人体面.jpg` |
| 苦夏搭子（随身手持风扇的陪伴感） | `images/expr_02_苦夏搭子.jpg` |
| 抽象降温（冰感蓝色系视觉，降温情绪氛围） | `images/expr_03_抽象降温.jpg` |
| 走秀配件（手持款配饰化，时尚人像） | `images/expr_04_走秀配件.jpg` |
| 白噪音 / 助眠（静音款叙事，极简卧室场景） | `images/expr_05_白噪音助眠.jpg` |

### 4. 整体版式 → Bento Grid + Hero

- 页头加 hero 区：大号渐变标题（用当期 5 个趋势色做文字渐变）+ 一句话副标，立即建立「时尚」调性。
- 放弃均匀栅格，改 Bento 式不规则拼版：年度色大卡、花纹图卡、表情图卡混排成杂志感版面（CSS Grid `grid-template-areas` 即可，不引入新库）。
- 克制的动效：卡片 hover 微浮起 + 阴影加深；滚动进入时淡入上移（IntersectionObserver 手写约 20 行即可；要更顺滑可加 framer-motion）。

### 5. 信息降噪

- `source` 统一收进卡片底部小灰字或 hover tooltip。
- `note` 超过一行折叠为「展开」。
- 页尾「数据来源」保留一行即可。

## 实现约束

- **主战场只有一个文件**：`frontend/src/features/dashboard/TrendGallery.jsx`。把 antd `Card` 换成自定义 div + 项目已有 CSS tokens（`--color-*`），不动路由、不动后端数据结构。
- colors / patterns / shapes / expressions 四个数组字段保持不变，只给 patterns / shapes / expressions 的条目**增加 image 字段**（本次先用 zip 里的 15 张图做本地静态资源）。
- 不新增依赖也能完成 80%（纯 CSS Grid + IntersectionObserver）；framer-motion 可选。
- 「抽象降温」这类概念图如果与品牌调性不统一，后续可改用 `backend/app/services/jimeng.py` 即梦生图服务重新生成——图片路径务必抽在数据里，不要硬编码进 JSX。

## 验收标准

1. 四个区块全部有图：色卡墙（120px+ 全出血）+ 15 张配图全部上卡。
2. 表情化区块不再出现空白卡片。
3. 有 hero 区 + Bento 不规则拼版，页面第一眼「图多字少、色彩扑面」。
4. 与 `design/03_最终企划案/03_Moodboard/时尚系列概念情绪板2.webp` 并排对比，气质接近。
5. 点击图片卡片无报错；色卡点击能复制 hex。
